
const BASE_URL = "https://xt2cpwt7-8000.inc1.devtunnels.ms/api";
export const apiUrl = BASE_URL;


