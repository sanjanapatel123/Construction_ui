
const BASE_URL = "https://hrb5wx2v-8000.inc1.devtunnels.ms/api";


// const BASE_URL = "https://8f803mj0-8000.inc1.devtunnels.ms/api";

export const apiUrl = BASE_URL;


