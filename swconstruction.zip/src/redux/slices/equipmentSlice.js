import { createAsyncThunk, createSlice } from "@reduxjs/toolkit"
import { apiUrl } from "../../utils/config";
import axiosInstance from "../../utils/axiosInstance";

export const  addEquipment = createAsyncThunk(
    'equipment/addEquipment',
    async (formData, thunkAPI) => {
        try{
            const response = await axiosInstance.post(`${apiUrl}/equipment`, formData);
            return response.data;
        }catch(error){
            return thunkAPI.rejectWithValue(error.response?.data || error.message || "error creating tool")
        }
})

export const fetchEquipment = createAsyncThunk(
    'equipment/fetchEquipment',
    async (_, thunkAPI) => {
        try{
            const response = await axiosInstance.get(`${apiUrl}/equipment`);
            return response.data;
        }catch(error){
            return thunkAPI.rejectWithValue(error.response?.data || error.message || "Unauthorized access")
        }
    }
)


const equipmentSlice = createSlice({
    name: 'equipment',
    initialState: {
        equipments: [],
        status: 'idle',
        error: null
    },
    reducers: {},

    extraReducers: (builder) => {
        builder
        .addCase(addEquipment.pending, (state) => {
            state.status = 'loading';
            state.error = null;
        })

          .addCase(addEquipment.fulfilled, (state, action) => {
            state.equipments.push(action.payload);
          })
          .addCase(addEquipment.rejected, (state, action) => {
            state.status = 'failed';
            state.error = action.payload;
          })
          .addCase(fetchEquipment.pending, (state) => {
            state.status = 'loading';
            state.error = null;
          })
          .addCase(fetchEquipment.fulfilled, (state, action) => {
            state.equipments = action.payload;
          })
          .addCase(fetchEquipment.rejected, (state, action) => {          
            state.status = 'failed';
            state.error = action.payload;
          })
      },

    
})

export default equipmentSlice.reducer