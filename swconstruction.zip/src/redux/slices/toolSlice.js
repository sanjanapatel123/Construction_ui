import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { apiUrl } from "../../utils/config"
import axiosInstance from "../../utils/axiosInstance";

export const addtool = createAsyncThunk( 'tool/addtool',
    async (formData, thunkAPI) => {
        try{
            const response = await axiosInstance.post(`${apiUrl}/plantmachinery`, formData);
            return response.data;
        }catch(error){
            return thunkAPI.rejectWithValue(error.response?.data || error.message || "error creating tool")
        }

    
})

export const getalltool = createAsyncThunk( 'tool/getalltool',
    async(_,thunkAPI) => {
        try{
            const response = await axiosInstance.get(`${apiUrl}/plantmachinery`)
            return response.data;
        }catch(error){
            return rejectWithValue(err.response.data);

        }
    }
)

export const deletetool = createAsyncThunk

const initialState = {
    tool: [],
    loading: false,
    error: null
}

const toolSlice = createSlice({
    name: "tool",
    initialState,
  

    extraReducers: (builder) => {
        builder
    .addCase( addtool.pending, (state) => {
        state.loading = true;
        state.error = null;
    })
    .addCase( addtool.fulfilled, (state, action) => {
        state.loading = false;
        state.tool = action.payload;
    })
    .addCase( addtool.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
    })
    .addCase( getalltool.pending, (state) => {
        state.loading = true;
        state.error = null;
    })
    .addCase( getalltool.fulfilled, (state, action) => {
        state.loading = false;
        state.tool = action.payload;
    })
    .addCase( getalltool.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
    })      
   }


})

export default toolSlice.reducer;